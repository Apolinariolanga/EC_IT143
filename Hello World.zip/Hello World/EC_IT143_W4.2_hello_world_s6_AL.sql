-- Question: What database am I currently using?

-- Answer: Step 1: Retrieve the name of the current database.
 
--         Step 2: Display the database name to verify the connection.


-- 1) Reload data

TRUNCATE TABLE dbo.t_hello_world;
 
INSERT INTO dbo.t_hello_world
(
DatabaseName
)
SELECT
DatabaseName 
FROM dbo.v_hello_world

-- 2) Review results

SELECT t.* 
  FROM dbo.t_hello_world as t;