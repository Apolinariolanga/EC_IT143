DROP VIEW IF EXISTS dbo.v_hello_world;
GO

CREATE OR ALTER VIEW dbo.v_hello_world
AS

/******************************************************************************************************

NAME: dbo.v_hello_world
PURPOSE: Create  the Hello World View

MODIFICATION LOG:
Ver          Date           Author               Description
_____       __________     _________             ___________________________________
1.0         10/01/2026      ALANGA               1. Built this script for EC IT143

RUNTIME:
1s

NOTES:
This script exists to help me learn step 4 of 8 in the Answer Focused Approach for T-SQL Data Manipulation

*********************************************************************************************************/

SELECT
    DB_NAME() AS DatabaseName;
GO

