CREATE OR ALTER PROCEDURE dbo.usp_hello_world
AS

/******************************************************************************************************

NAME: dbo.usp_hello_world
PURPOSE: Create user stored procedure - Hello World

MODIFICATION LOG:
Ver          Date           Author               Description
_____       __________     _________             ___________________________________
1.0         10/01/2026      ALANGA               1. Built this script for EC IT143

RUNTIME:
1s

NOTES:
This script exists to help me learn step 7 of 8 in the Answer Focused Approach for T-SQL Data Manipulation

*********************************************************************************************************/



BEGIN

-- 1) Reload data

    TRUNCATE TABLE dbo.t_hello_world;

    INSERT INTO dbo.t_hello_world
    (
        DatabaseName
    )
    SELECT
        DatabaseName
    FROM dbo.v_hello_world;

-- 2) Review the results

SELECT t.*
  FROM dbo.t_hello_world as t

END;
GO