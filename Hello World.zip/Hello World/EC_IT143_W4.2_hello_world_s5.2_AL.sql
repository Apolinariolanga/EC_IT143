DROP TABLE IF EXISTS dbo.t_hello_world;
GO
 
CREATE TABLE dbo.t_hello_world
(
DatabaseName VARCHAR(128) NOT NULL,
 
CONSTRAINT PK_CurrentDatabase
PRIMARY KEY (DatabaseName));
GO