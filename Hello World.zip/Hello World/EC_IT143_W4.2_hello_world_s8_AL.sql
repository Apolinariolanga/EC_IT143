-- Question: What database am I currently using?
 
-- Let's Display the database name


EXEC dbo.usp_hello_world;

