-- Question: What database am I currently using?

-- Answer: Step 1: Retrieve the name of the current database.
 
--         Step 2: Display the database name to verify the connection.


SELECT
DB_NAME() AS DatabaseName;