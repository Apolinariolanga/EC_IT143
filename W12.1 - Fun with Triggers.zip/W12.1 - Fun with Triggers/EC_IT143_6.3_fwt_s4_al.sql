CREATE OR ALTER TRIGGER trg_UpdateAuditInfo
ON dbo.t_w3_schools_customers
AFTER UPDATE
AS
/*****************************************************************************************************************
NAME:    dbo.trg_UpdateAuditInfo
PURPOSE: Last Modified by Trigger

MODIFICATION LOG:
Ver      Date        Author        Description
-----   ----------   -----------   -------------------------------------------------------------------------------
1.0     10/16/2026   ALANGA       1. Built this script for EC IT143


RUNTIME: 
1s

NOTES: 
Keep track of the last modified date and user for each row in the table
 
******************************************************************************************************************/

BEGIN

    SET NOCOUNT ON;

    UPDATE c
       SET LastModifiedDate = GETDATE(),
           LastModifiedBy = SUSER_NAME()
    FROM dbo.t_w3_schools_customers c
         INNER JOIN inserted i
             ON c.CustomerID = i.CustomerID;

END;
GO