
-- Research Source:
-- https://learn.microsoft.com/en-us/sql/t-sql/statements/create-trigger-transact-sql
