-- How can I track the last modified date of a record?
-- How to keep track of when a record was last modified?
-- With the below the initial insert will be recorded

-- ALTER TABLE dbo.t_w3_schools_customers
-- ADD LastModifiedDate DATETIME NULL,
-- LastModifiedBy VARCHAR(128) NULL;

-- How to keep track of who last modified a record?

-- A trigger can fire automatically after an update.

-- Create an AFTER UPDATE trigger.