-- How can I extract the last name from ContactName?

CREATE OR ALTER FUNCTION dbo.fn_GetLastName
(
      @ContactName VARCHAR(100)
)
RETURNS VARCHAR(100)
AS
BEGIN

    DECLARE @LastName VARCHAR(100);

    SET @LastName =
        SUBSTRING(
            @ContactName,
            CHARINDEX(' ', @ContactName + ' ') + 1,
            LEN(@ContactName)
        );

    RETURN @LastName;

END;
GO


SELECT
      ContactName
    , dbo.fn_GetLastName(ContactName) AS LastName
FROM dbo.t_w3_schools_customers;