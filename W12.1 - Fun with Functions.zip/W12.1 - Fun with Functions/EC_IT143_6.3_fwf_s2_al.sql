-- Question: How can I extract the first name from ContactName?

-- A: Use functions to extract everything before the first space to get only the first name