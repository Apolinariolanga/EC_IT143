-- Question: How can I extract the first name from ContactName?

-- A: Use functions to extract everything before the first space to get only the first name

SELECT t.ContactName
FROM dbo.t_w3_schools_customers AS t
ORDER BY 1;