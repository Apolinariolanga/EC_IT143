CREATE OR ALTER FUNCTION [dbo].[fn_GetFirstName]
(
      @ContactName AS VARCHAR(100)
)
RETURNS VARCHAR(100)

/*****************************************************************************************************************
NAME:    dbo.fn_GetFirstName
PURPOSE: Gets first name from combined name

MODIFICATION LOG:
Ver      Date        Author        Description
-----   ----------   -----------   -------------------------------------------------------------------------------
1.0     10/16/2026   ALANGA       1. Built this script for EC IT143


RUNTIME: 
1s

NOTES: 
Returns the first name from a contact name.
 
******************************************************************************************************************/

BEGIN

    DECLARE @FirstName VARCHAR(100);

    SET @FirstName =
        LEFT(@ContactName,
             CHARINDEX(' ', @ContactName + ' ') - 1);

    RETURN @FirstName;

END;
GO