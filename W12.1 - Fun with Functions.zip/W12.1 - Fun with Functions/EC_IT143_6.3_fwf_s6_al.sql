-- Question: How can I extract the first name from ContactName?

-- A: Use functions to extract everything before the first space to get only the first name
-- Research Source from learn microsoft search using google
-- https://learn.microsoft.com/en-us/sql/t-sql/functions/charindex-transact-sql

-- CHARINDEX finds the first space.
-- LEFT returns characters before that space.


SELECT
    ContactName,
    LEFT(
        ContactName,
        CHARINDEX(' ', ContactName + ' ') - 1
    ) AS AdHocResult, dbo.fn_GetFirstName(ContactName) AS FunctionResult
FROM dbo.t_w3_schools_customers; 

