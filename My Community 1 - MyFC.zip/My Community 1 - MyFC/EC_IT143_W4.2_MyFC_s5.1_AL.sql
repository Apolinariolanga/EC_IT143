-- Question: How many players are on each team?

-- Answer: Count each players per team


SELECT *
INTO dbo.t_players_per_team
FROM dbo.v_players_per_team;