-- Question: How many players are on each team?

-- Answer: Count each players per team


