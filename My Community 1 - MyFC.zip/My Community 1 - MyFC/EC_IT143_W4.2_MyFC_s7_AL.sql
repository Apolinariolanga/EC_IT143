CREATE OR ALTER PROCEDURE dbo.usp_players_per_team
AS

/******************************************************************************************************

NAME: dbo.usp_players_per_team
PURPOSE: Create user stored procedure - Players per team

MODIFICATION LOG:
Ver          Date           Author               Description
_____       __________     _________             ___________________________________
1.0         10/01/2026      ALANGA               1. Built this script for EC IT143

RUNTIME:
1s

NOTES:
This script exists to help me learn step 7 of 8 in the Answer Focused Approach for T-SQL Data Manipulation

*********************************************************************************************************/



BEGIN


-- 1) Reload data

TRUNCATE TABLE dbo.t_players_per_team;
 
INSERT INTO dbo.t_players_per_team
(
Team,
PlayerCount
)
SELECT
Team,
PlayerCount
FROM dbo.v_players_per_team;

-- 2) Review results

SELECT t.* 
  FROM dbo.t_players_per_team as t;