-- Question: How many players are on each team?

-- Answer: Count each players per team


-- 1) Reload data

TRUNCATE TABLE dbo.t_players_per_team;
 
INSERT INTO dbo.t_players_per_team
(
Team,
PlayerCount
)
SELECT
Team,
PlayerCount
FROM dbo.v_players_per_team;

-- 2) Review results

SELECT t.* 
  FROM dbo.t_players_per_team as t;