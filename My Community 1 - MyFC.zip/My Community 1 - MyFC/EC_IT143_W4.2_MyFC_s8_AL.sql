-- Question: How many players are on each team?

-- Answer: Count each players per team


EXEC dbo.usp_players_per_team;

