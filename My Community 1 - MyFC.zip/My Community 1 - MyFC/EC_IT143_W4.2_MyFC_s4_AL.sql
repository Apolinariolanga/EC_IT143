DROP VIEW IF EXISTS dbo.v_players_per_team;
GO

CREATE OR ALTER VIEW dbo.v_players_per_team
AS

/******************************************************************************************************

NAME: v_players_per_team
PURPOSE: Create the View that show players per team

MODIFICATION LOG:
Ver          Date           Author               Description
_____       __________     _________             ___________________________________
1.0         10/01/2026      ALANGA               1. Built this script for EC IT143

RUNTIME:
1s

NOTES:
This script exists to help me learn step 4 of 8 in the Answer Focused Approach for T-SQL Data Manipulation

*********************************************************************************************************/

SELECT
t.t_code AS Team,
COUNT(p.pl_id) AS PlayerCount
FROM tblPlayerDim p
INNER JOIN tblTeamDim t
ON p.t_id = t.t_id
GROUP BY t.t_code
ORDER BY t.t_code;