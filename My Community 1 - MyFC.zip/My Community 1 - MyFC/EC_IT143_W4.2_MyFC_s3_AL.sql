-- Question: How many players are on each team?

-- Answer: Count each players per team


SELECT
t.t_code AS Team,
COUNT(p.pl_id) AS PlayerCount
FROM tblPlayerDim p
INNER JOIN tblTeamDim t
ON p.t_id = t.t_id
GROUP BY t.t_code
ORDER BY t.t_code;