DROP TABLE IF EXISTS dbo.t_players_per_team;
GO
 
CREATE TABLE dbo.t_players_per_team
(
Team VARCHAR(10) NOT NULL,
PlayerCount INT NOT NULL,
 
CONSTRAINT PK_players_per_team
PRIMARY KEY (Team)
);
GO