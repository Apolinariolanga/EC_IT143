DROP TABLE IF EXISTS dbo.t_cardmember_total_spent;
GO
 
CREATE TABLE dbo.t_cardmember_total_spent
(
CardMemberID INT NOT NULL,
TotalSpent DECIMAL(18,2) NOT NULL,
 
CONSTRAINT PK_cardmember_total_spent
PRIMARY KEY (CardMemberID)
);