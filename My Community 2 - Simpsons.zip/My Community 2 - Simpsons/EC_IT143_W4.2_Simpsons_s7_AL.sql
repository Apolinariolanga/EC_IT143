CREATE OR ALTER PROCEDURE dbo.p_load_cardmember_total_spent
AS

/******************************************************************************************************

NAME: dbo.p_load_cardmember_total_spent
PURPOSE: Create user stored procedure - Card members total spent

MODIFICATION LOG:
Ver          Date           Author               Description
_____       __________     _________             ___________________________________
1.0         10/06/2026      ALANGA               1. Built this script for EC IT143

RUNTIME:
1s

NOTES:
This script exists to help me learn step 7 of 8 in the Answer Focused Approach for T-SQL Data Manipulation

*********************************************************************************************************/



BEGIN


-- 1) Reload data

TRUNCATE TABLE dbo.t_cardmember_total_spent;
 
INSERT INTO dbo.t_cardmember_total_spent
(
CardMemberID,
TotalSpent
)
SELECT
CardMemberID,
TotalSpent
FROM dbo.v_cardmember_total_spent;

END;
GO

-- 2) Review results

SELECT t.* 
  FROM dbo.t_cardmember_total_spent as t;