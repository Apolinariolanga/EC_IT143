-- Question: What is the total amount spent by each card member?

-- Answer: Identify each card member and their transactions, Calculate the total amount spent by each card member


-- 1) Reload data

TRUNCATE TABLE dbo.t_cardmember_total_spent;
 
INSERT INTO dbo.t_cardmember_total_spent
(
CardMemberID,
TotalSpent
)
SELECT
CardMemberID,
TotalSpent
FROM dbo.v_cardmember_total_spent;

-- 2) Review results

SELECT t.* 
  FROM dbo.t_cardmember_total_spent as t; 