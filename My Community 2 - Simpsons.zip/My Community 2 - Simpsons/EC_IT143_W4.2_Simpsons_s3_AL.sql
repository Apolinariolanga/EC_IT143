-- Question: What is the total amount spent by each card member?

-- Answer: Identify each card member and their transactions, Calculate the total amount spent by each card member


SELECT
CardMemberID,
SUM(AmountSpent) AS TotalSpent
FROM tblCardTransactions
GROUP BY CardMemberID
ORDER BY TotalSpent DESC;