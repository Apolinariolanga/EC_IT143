-- Question: What is the total amount spent by each card member?

-- Answer: Identify each card member and their transactions, Calculate the total amount spent by each card member


SELECT *
INTO dbo.t_cardmember_total_spent
FROM dbo.v_cardmember_total_spent;