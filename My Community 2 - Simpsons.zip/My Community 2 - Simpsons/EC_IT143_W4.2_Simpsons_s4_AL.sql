DROP VIEW IF EXISTS dbo.v_cardmember_total_spent;
GO

CREATE OR ALTER VIEW dbo.v_cardmember_total_spent
AS

/******************************************************************************************************

NAME: v_cardmember_total_spent
PURPOSE: Create the View that show players per team

MODIFICATION LOG:
Ver          Date           Author               Description
_____       __________     _________             ___________________________________
1.0         10/01/2026      ALANGA               1. Built this script for EC IT143

RUNTIME:
1s

NOTES:
This script exists to help me learn step 4 of 8 in the Answer Focused Approach for T-SQL Data Manipulation

*********************************************************************************************************/

SELECT
CardMemberID,
SUM(AmountSpent) AS TotalSpent
FROM tblCardTransactions
GROUP BY CardMemberID;
GO
 
SELECT *
FROM dbo.v_cardmember_total_spent;